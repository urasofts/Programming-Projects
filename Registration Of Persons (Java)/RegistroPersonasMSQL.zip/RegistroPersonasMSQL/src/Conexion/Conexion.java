package Conexion;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Jair Martinez
 */
public class Conexion {
    Connection conn = null;

    public Connection conectar() {
       
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost/regpersona","root","");    
                System.out.println("Conexión establecida con la base de datos");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("Error al conectar con la base de datos " + e);
            }
        
        return conn;
    }
}