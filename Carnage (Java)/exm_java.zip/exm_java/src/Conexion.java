/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author SENA
 */
public class Conexion {
    Connection Rconector = null;
    public Connection conectar(){
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Rconector = DriverManager.getConnection("jdbc:mysql://localhost:3306/carnes_java","root","");           
        }
        catch(ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, "Error"+e);
        }
        return Rconector;
    }

}

